#pragma once

#include <stdint.h>

#include "esp_err.h"
#include "services/vision/face_detector.h"

#ifdef __cplusplus
extern "C" {
#endif

#define FACE_RECOG_MAX_NAME_LEN 32

/*
 * Initializes recognition from one shared /sdcard/FACE.DB database.
 * The database is rebuilt automatically when the RGB enrollment dataset under
 * /sdcard/enroll/<person-name>/ changes.
 */
esp_err_t face_recognition_init(void);

esp_err_t face_recognition_recognize(
    uint8_t *camera_buf,
    uint32_t width,
    uint32_t height,
    const face_box_t *box,
    char *out_name,
    int out_name_len,
    float *out_score
);

int face_recognition_get_count(void);

#ifdef __cplusplus
}
#endif
